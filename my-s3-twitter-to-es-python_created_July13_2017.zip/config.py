'''
Created on Oct 12, 2015

@author: mentzera
'''

es_host = 'search-es-twitter-stream-dev-rzmtjuphpnhuukihhzbhwqtapm.us-west-2.es.amazonaws.com'
es_port = 80
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

