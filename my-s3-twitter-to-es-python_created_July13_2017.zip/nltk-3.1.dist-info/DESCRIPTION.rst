The Natural Language Toolkit (NLTK) is a Python package for
natural language processing.  NLTK requires Python 2.7, or 3.2+.

