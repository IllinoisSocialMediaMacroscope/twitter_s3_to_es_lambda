'''
Created on Oct 12, 2015

@author: mentzera
'''

es_host = 'search-es-twitter-stream-yugu6rvjulzswrsj2y764qyy5i.us-west-2.es.amazonaws.com'
es_port = 443
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

